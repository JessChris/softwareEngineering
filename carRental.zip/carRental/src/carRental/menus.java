package carRental;

public class menus 
{
	public static void menuMain()
	{
		System.out.println("1. Show Client");
		System.out.println("2. ");
		System.out.println("-1. Exit (choices will NOT be saved)");
	}
}
